<?php

$arModuleVersion = [
    'VERSION'      => '1.1.0',
    'VERSION_DATE' => '2026-07-17 00:00:00',
];
